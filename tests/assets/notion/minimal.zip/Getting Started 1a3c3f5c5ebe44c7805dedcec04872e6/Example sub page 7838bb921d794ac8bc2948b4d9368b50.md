# Example sub page

In Notion, you can nest pages inside pages inside pages... infinitely. No more messy folders!

![Example%20sub%20page%207838bb921d794ac8bc2948b4d9368b50/subpages.gif](Example%20sub%20page%207838bb921d794ac8bc2948b4d9368b50/subpages.gif)

**Tip:** Click the `⋮⋮` to the left of any content and drag to the far left or right to create columns. Use the blue lines to guide you.

![Example%20sub%20page%207838bb921d794ac8bc2948b4d9368b50/personalhomecolumns2.gif](Example%20sub%20page%207838bb921d794ac8bc2948b4d9368b50/personalhomecolumns2.gif)

👈 To go back, click the link at the top left, or use your sidebar.