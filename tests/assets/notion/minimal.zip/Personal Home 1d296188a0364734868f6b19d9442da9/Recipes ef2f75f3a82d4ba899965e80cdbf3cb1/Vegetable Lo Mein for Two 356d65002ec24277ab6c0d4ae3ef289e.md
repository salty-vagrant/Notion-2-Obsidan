# Vegetable Lo Mein for Two

Link: https://www.forkinthekitchen.com/vegetable-lo-mein-for-two/
Tags: Dinner

## Ingredients

- 4 ounces [Chinese noodles](https://www.amazon.com/gp/product/B0052P1AS4/ref=as_li_tl?ie=UTF8&camp=1789&creative=9325&creativeASIN=B0052P1AS4&linkCode=as2&tag=forinthekit-20&linkId=10c383c442cc85ec6122caa764a31d1e) (1/2 package)
- 1 Tablespoon oyster sauce
- 1/2 teaspoon sesame oil
- 1 Tablespoon dark soy sauce
- 1 Tablespoon light (regular) soy sauce
- 1 1/2 Tablespoons vegetable oil
- 1/2 yellow onion, thinly sliced
- 2 garlic cloves, thinly sliced
- 1 cup shredded carrots (2 medium)
- 1 bell pepper, thinly sliced
- 3-4 ounces snow peas

## Instructions

1. Boil a large pot of water; cook Chinese noodles for 1-2 minutes, stirring to unfold. Drain, rinse, and set aside.
2. In a small bowl, whisk together oyster sauce, sesame oil, and soy sauces. Set aside.
3. In a wok, heat vegetable oil over medium heat. Add onion slices and cook for 4-5 minutes until tender. Add garlic, continuing to stir for 1 minute as it becomes fragrant. Add carrots, bell pepper, and snow peas. Cook for 4-5 minutes until tender.
4. Add cooked noodles, sauce, and stir to coat. Continue to cook for 2 minutes until noodles are cooked through and sauce is distributed evenly.